   angular.module('customTriggerExample', [])
    .controller('ExampleController', ['$scope', function($scope) {
      $scope.user = {};
    }]);