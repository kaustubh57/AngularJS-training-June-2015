var main = angular.module('main',['ngGrid','ui.bootstrap.demo']);
main.controller('FormCtrl', ['$scope', function(s) {
		// $scope.name='Ravi';

		s.delete=function(selectedIndex){
			s.users.splice(selectedIndex, 1);
		};
		s.dateOptions={
			// initDate:new Date(),
			formatYear: 'yy',
    		startingDay: 1
		}
		s.open = function($event) {
		    $event.preventDefault();
		    $event.stopPropagation();

		    s.opened = true;
		  };
		s.colors = [
		      {name:'black', shade:'dark'},
		      {name:'white', shade:'light'},
		      {name:'red', shade:'dark'},
		      {name:'blue', shade:'dark'},
		      {name:'yellow', shade:'light'}
		    ];
		s.genders={
			male:'Male11',
			female:'Female'
		}
		s.getColor=function(age){
			return age>40 ?'green':'gray';
		}
		s.users=[];
		s.user={fname:'Rajiv',
			gender:'f'};
		s.user.languages=[];
		s.mySelections = [];
		s.batchDelete=function(){
			angular.forEach( s.users,
				function(value, index){
					if(value.selected){		
						s.users.splice(index,1);
					}
				});
			}
			s.disabled = function(date, mode) {
    return ( mode === 'day' && ( date.getDay() === 0 || date.getDay() === 6 ) );
  };
		 var filterBarPlugin = {
	        init: function(scope, grid) {
	            filterBarPlugin.scope = scope;
	            filterBarPlugin.grid = grid;
	            s.$watch(function() {
	                var searchQuery = "";
	                angular.forEach(filterBarPlugin.scope.columns, function(col) {
	                    if (col.visible && col.filterText) {
	                        var filterText = (col.filterText.indexOf('*') == 0 ? col.filterText.replace('*', '') : "^" + col.filterText) + ";";
	                        searchQuery += col.displayName + ": " + filterText;
	                        // searchQuery += col.displayName + ": " + col.filterText;
	                    }
	                });
	                return searchQuery;
	            }, function(searchQuery) {
	                filterBarPlugin.scope.$parent.filterText = searchQuery;
	                filterBarPlugin.grid.searchProvider.evalFilter();
	            });
	        },
	        scope: undefined,
	        grid: undefined,
    };
    s.$on('ngGridEventEndCellEdit', function() {
                console.log('testing');
            })
		s.gridOptions = { 
			groups:['lname'],
			// selectedItems: s.mySelections,//selections
			// multiSelect: true,
			// enableCellSelection: true,
   //      enableRowSelection: false,
   //      enableCellEditOnFocus: true,
        	enableCellEdit: true,
			data: 'users',
			showGroupPanel: true,
			showFilter:true,
			// filterOptions:{ filterText: '', useExternalFilter: false },
			showColumnMenu:true,
			afterSelectionChange:function(rowItem, event){
				console.log(arguments);
				rowItem.entity.selected=rowItem.selected;
				// s.mySelections.push(rowItem);
			},
			showSelectionCheckbox:true,
			plugins: [filterBarPlugin],
			 headerRowHeight: 60, // give room for filter bar
			 columnDefs: [
			 {field:'fname', displayName:'FName',
			enableCellEdit: true,
			// headerCellTemplate: 'templates/filterHeaderTemplate.html'
		}, 

			 {field:'age', displayName:'Age', 
			 // cellFilter	:'',
			cellTemplate: 'templates/cellTemplate.html',
			headerCellTemplate: 'templates/filterHeaderTemplate.html'
		},
			 {field:'lname', displayName:'LNAME',
			headerCellTemplate: 'templates/filterHeaderTemplate.html'
			}],
		// 	 {field:'color.name', displayName:'Color',
		// 	headerCellTemplate: 'templates/filterHeaderTemplate.html'}],
		// 	 rowTemplate:'<div style="height: 100%" ng-class="{green: row.getProperty(\'age\') < 30}"><div ng-style="{ \'cursor\': row.cursor }" ng-repeat="col in renderedColumns" ng-class="col.colIndex()" class="ngCell ">' +
  //                          '<div class="ngVerticalBar" ng-style="{height: rowHeight}" ng-class="{ ngVerticalBarVisible: !$last }"> </div>' +
  //                          '<div ng-cell></div>' +
  //                    '</div></div>'
    
			  };

		s.getSelectedLanguages=function(user){
			var result = "";
			angular.forEach(user.languages, function(value, key){
				if(value){
					result= result+value+",";				}
			});
			return result;
		}
		// s.$watch('')
		s.save =function(){
			s.users.push(angular.copy(s.user));
			s.user.languages=[];
			console.log(s.name);
		}
		s.updateLanguage=function(){
			console.log(arguments);
		}
}]);