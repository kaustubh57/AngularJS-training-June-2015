var main = angular.module('main',['ngGrid']);
main.controller('FormCtrl', ['$scope', function(s) {
		// $scope.name='Ravi';
		s.delete=function(selectedIndex){
			s.users.splice(selectedIndex, 1);
		};
		s.colors = [
		      {name:'black', shade:'dark'},
		      {name:'white', shade:'light'},
		      {name:'red', shade:'dark'},
		      {name:'blue', shade:'dark'},
		      {name:'yellow', shade:'light'}
		    ];
		s.genders={
			male:'Male11',
			female:'Female'
		}
		s.getColor=function(age){
			return age>40 ?'green':'gray';
		}
		s.users=[];
		s.user={fname:'Rajiv',
			gender:'f'};
		s.user.languages=[];
		
		s.gridOptions = { 
			data: 'users',
			showGroupPanel: true,
			 columnDefs: [{field:'fname', displayName:'FName'}, 
			 {field:'age', displayName:'Age',
			cellTemplate: 'templates/cellTemplate.html'},
			 {field:'lname', displayName:'LNAME'},
			 {field:'color.name', displayName:'Color'}],
			 rowTemplate:'<div style="height: 100%" ng-class="{green: row.getProperty(\'age\') < 30}"><div ng-style="{ \'cursor\': row.cursor }" ng-repeat="col in renderedColumns" ng-class="col.colIndex()" class="ngCell ">' +
                           '<div class="ngVerticalBar" ng-style="{height: rowHeight}" ng-class="{ ngVerticalBarVisible: !$last }"> </div>' +
                           '<div ng-cell></div>' +
                     '</div></div>'
    
			  };

		s.getSelectedLanguages=function(user){
			var result = "";
			angular.forEach(user.languages, function(value, key){
				if(value){
					result= result+value+",";				}
			});
			return result;
		}
		s.save =function(){
			s.users.push(angular.copy(s.user));
			s.user.languages=[];
			console.log(s.name);
		}
		s.updateLanguage=function(){
			console.log(arguments);
		}
}]);