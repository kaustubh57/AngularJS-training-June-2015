angular.module('myApp', []);

angular.module('myApp').controller('MainController', function($scope) {
  
  $scope.message = 'AngularJS is good';
  
  $scope.showMessage=function(){
    console.log('Message Changed');
  }
});

angular.module('myApp').directive('helloWorld', function($filter) {
  return {
    restrict: 'E',
    scope:{
      message1:'@messageAttr',  //@ for one-way binding, = for 2-way binding
      showMessage:'&showMessageAttr',
    },
    replace: false,
    transclude:true,
    // template: '<p ng-click="clearMessage()">Hello, World! <div ng-transclude></div>  {{message1}} </p>',
    templateUrl:'template.tpl',
    link: function(scope, elem, attrs) {
      console.log('calling link fn');
      scope.$watch('message1', function(value) {
        // scope.showMessage();
        var result = $filter('uppercase')(value);
        scope.message1 = result;
      });
      // elem.  
      scope.clearMessage = function() {
        scope.message1 = '';
      }
      scope.$on('$destroy', function() {
        console.log("destroyed");
        console.log(arguments);
      });
      elem.bind('mouseover', function() {
        elem.css('cursor', 'pointer');
      });

    },
  }
});