angular.module('myApp', []);

angular.module('myApp').controller('MainController', function($scope) {
  
  $scope.message = 'message from controller scope';
  $scope.showMessage=function(){
    console.log('Message Changed');
  }
  $scope.test={
    age:20
  }
});

angular.module('myApp').directive('helloWorld', function($filter) {
  return {
    restrict: 'AE',
    scope:true,
    scope:{

          message1:'=messageAttr',  //@ for string value, = for json object
          showMessage:'&showMessageAttr',
        },
    replace: false,  //deprecated in 1.3+
    transclude:true,
    // template: '<p ng-click="clearMessage()">Hello, World!   {{message1}} </p>',
    templateUrl:'template.tpl',
    link: function(scope, elem, attrs) {
      console.log('calling link fn');
      scope.$watch('message1.age', function(value) {
        console.log(arguments);
        // var result = $filter('uppercase')(value);
        // scope.message1 = result;
        scope.showMessage();
      });
      // elem.  
      scope.clearMessage = function() {
        scope.message1 = '';
      }
      scope.$on('$destroy', function() {
        console.log("destroyed");
        console.log(arguments);
      });
      elem.bind('mouseover', function() {
        elem.css('cursor', 'pointer');
      });

    },
  }
});