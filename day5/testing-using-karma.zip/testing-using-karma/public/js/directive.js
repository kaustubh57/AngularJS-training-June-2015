angular.module('button-directive', [])

.directive('button', function() {
  return {
    restrict: 'E',
    link:function(){
      console.log(arguments);
    },
    compile: function(element, attributes) {
      element.addClass('btn');
      console.log('compile...')
      if ( attributes.type === 'submit' ) {
        element.addClass('btn-primary');
      }
      if ( attributes.size ) {
        element.addClass('btn-' + attributes.size);
      }
    }
  };
});